package com.orientechnologies.orient.core.config;

public interface OStorageConfigurationUpdateListener {
  void onUpdate(OStorageConfiguration update);
}
