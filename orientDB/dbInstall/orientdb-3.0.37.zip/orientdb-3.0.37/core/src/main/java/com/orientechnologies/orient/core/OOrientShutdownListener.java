package com.orientechnologies.orient.core;

/**
 * @author Andrey Lomakin (a.lomakin-at-orientdb.com) <a href="mailto:lomakin.andrey@gmail.com">Andrey Lomakin</a>
 * @since 09/01/15
 */
public interface OOrientShutdownListener {
	void onShutdown();
}
