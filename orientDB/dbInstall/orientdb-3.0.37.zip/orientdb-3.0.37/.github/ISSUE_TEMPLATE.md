### OrientDB Version: <version here>  
### Java Version: <version here>  
### OS: <os here>  

## Expected behavior  
<add here>  

## Actual behavior  
<add here>  

## Steps to reproduce  
<add here>  

